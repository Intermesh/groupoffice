Ext.override(go.groups.GroupDialog, {
    initFormItems: go.groups.GroupDialog.prototype.initFormItems.createSequence(function () {

        this.addPanel(
            new Ext.Panel({
                title: t('Email template'),
                layout: 'form',
                items: [
                    {
                        xtype: 'fieldset',
                        items: [
                            new go.modules.invicta.grouptemplates.TemplateCombo({
                                name: 'templateId',
                                fieldLabel: t('Template'),
                                anchor: '100%',
                            }),
                            {
                                xtype: 'box',
                                height: dp(10),
                            },
                            this.applyToUsersButton = new Ext.Button({
                                xtype: 'button',
                                text: t('Apply template to all group members'),
                                handler: function () {
                                    go.Jmap.request({
                                        method: 'invicta/grouptemplates/GroupTemplate/applyTemplateToGroupUsers',
                                        params: {
                                            entityId: 1,
                                        }
                                    });
                                }
                            }),
                        ],
                    },
                ]
            })
        );
    }),

    initComponent: go.groups.GroupDialog.prototype.initComponent.createSequence(function () {
        this.formPanel.on('setvalues', function(formPanel, values) {
            this.applyToUsersButton.setDisabled(!values.templateId);
        }, this);
    }),
});