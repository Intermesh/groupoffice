go.Modules.register("invicta", 'grouptemplates', {

    title: t('Group Templates'),

    entities: [],

    systemSettingsPanels: [
        "go.modules.invicta.grouptemplates.SystemSettingsPanel"
    ]
});
