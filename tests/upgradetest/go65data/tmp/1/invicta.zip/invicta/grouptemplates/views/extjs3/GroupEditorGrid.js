go.modules.invicta.grouptemplates.GroupEditorGrid = Ext.extend(go.grid.EditorGridPanel, {

    initComponent: function () {

        var templatesCombo = new go.modules.invicta.grouptemplates.TemplateCombo();

        this.store = new go.data.Store({
            filters: {
                hideUsers: {
                    hideUsers: true
                }
            },
            fields: [
                'id',
                'name',
                'isUserGroupFor',
                'aclId',
                {name: 'users', type: "relation", limit: 5},
                'templateId',
            ],
            entityStore: "Group",
        });

        Ext.apply(this, {
            tbar: [
                '->',
                {
                    xtype: 'tbsearch',
                    filters: [
                        'text'
                    ]
                }
            ],
            columns: [
                {
                    id: 'name',
                    header: t('Name'),
                    width: dp(200),
                    sortable: true,
                    hideable: false,
                    dataIndex: 'name',
                },
                {
                    id: 'template',
                    header: t("Template"),
                    dataIndex: 'templateId',
                    menuDisabled: true,
                    editor: templatesCombo,
                    width: dp(260),
                    hideable: false,
                    renderer: function (value) {
                        var record = templatesCombo.store.getById(value);
                        if (record) {
                            return record.get('name');
                        }
                        return value;
                    },
                    sortable: true
                },
                {
                    id: 'templateOwner',
                    header: t("Template Owner"),
                    dataIndex: 'templateId',
                    menuDisabled: true,
                    hidden: true,
                    hideable: true,
                    width: dp(260),
                    renderer: function (value) {
                        var record = templatesCombo.store.getById(value);
                        if (record) {
                            return record.get('user_name');
                        }
                        return value;
                    },
                    sortable: false
                }
            ],
            viewConfig: {
                emptyText: '<i>description</i><p>' + t("No items to display") + '</p>',
                scrollOffset: 0
            },
            autoExpandColumn: 'template',
            listeners: {
                scope: this,
                afterEdit: function() {
                    this.store.save();
                }
            }
        });

        go.modules.invicta.grouptemplates.GroupEditorGrid.superclass.initComponent.call(this);

        this.on('viewready', function () {
            this.store.load();
        }, this);
    },
});