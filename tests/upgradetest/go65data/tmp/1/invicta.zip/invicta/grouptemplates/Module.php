<?php

namespace go\modules\invicta\grouptemplates;

use GO\Base\Model\Template;
use go\core;
use go\core\model\User;
use go\core\model\Group;
use go\core\orm\Property;
use GO\Email\Model\DefaultTemplate;
use go\modules\invicta\grouptemplates\model\GroupTemplate;

/**
 * Class Module
 * @package go\modules\invicta\grouptemplates
 */
class Module extends core\Module
{
    /**
     * Return the name of the author.
     *
     * @return string
     */
    public function getAuthor()
    {
        return 'Michal Charvat <info@michalcharvat.cz>"';
    }

    /**
     *
     */
    public function defineListeners()
    {
        User::on(User::EVENT_SAVE, static::class, 'onUserSave');
        Group::on(Property::EVENT_MAPPING, static::class, 'onGroupMap');
    }

    /**
     * @param User $user
     * @throws \GO\Base\Exception\AccessDenied
     */
    public static function onUserSave(User $user)
    {
        if ($user->isNew()) {

            $templateRow = (new core\orm\Query())
                ->select('cgdt.templateId')->distinct()
                ->from('core_user_group', 'cug')
                ->join('core_group_default_template', 'cgdt', 'cgdt.groupId = cug.groupId')
                ->where(['userId' => $user->id])
                ->andWhere('cgdt.templateId IS NOT NULL')
                ->single();

            //heck if default template exists
            if (!$templateRow) {
                return;
            }

            //load template record
            $templateRecord = Template::model()->findByPk($templateRow['templateId']);
            if ($templateRecord) {
                //apply template to user
                GroupTemplate::applyTemplateToUser($templateRecord, $user->id);
            }
        }
    }

    /**
     * @param core\orm\Mapping $mapping
     * @return bool
     */
    public static function onGroupMap(core\orm\Mapping $mapping)
    {
        $mapping->addTable('core_group_default_template', 'cgdt', ['id' => 'groupId'], ['templateId']);
        return true;
    }
}