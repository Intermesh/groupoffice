CREATE TABLE `core_group_default_template`
(
    `groupId`    int(11) NOT NULL,
    `templateId` int(11) NOT NULL,
    PRIMARY KEY (`groupId`, `templateId`),
    KEY          `groupId` (`groupId`),
    KEY          `templateId` (`templateId`),
    CONSTRAINT `core_group_default_template_ibfk_1` FOREIGN KEY (`groupId`) REFERENCES `core_group` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
    CONSTRAINT `core_group_default_template_ibfk_2` FOREIGN KEY (`templateId`) REFERENCES `go_templates` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
