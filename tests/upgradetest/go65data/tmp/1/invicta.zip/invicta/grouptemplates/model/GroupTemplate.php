<?php

namespace go\modules\invicta\grouptemplates\model;

use GO\Base\Db\ActiveRecord;
use GO\Base\Model\Template;
use go\core\model\User;
use go\core\orm\Property;
use GO\Email\Model\DefaultTemplate;

class GroupTemplate extends Property
{
    /**
     * Primary key to User id
     *
     * @var int
     */
    public $groupId;

    /**
     * @var int
     */
    public $templateId;

    /**
     * @return \go\core\orm\Mapping
     */
    protected static function defineMapping()
    {
        return parent::defineMapping()->addTable('core_group_default_template', 'cgdt');
    }

    /**
     * @return string|null
     * @throws \GO\Base\Exception\AccessDenied
     */
    public function getTemplateName()
    {
        $templateRecord = Template::model()->findByPk($this->templateId);
        if (!$templateRecord) {
            return null;
        }

        return $templateRecord->name;
    }

    /**
     * @param ActiveRecord $templateRecord
     * @param $userId
     * @throws \GO\Base\Exception\AccessDenied
     */
    public static function applyTemplateToUser($templateRecord, $userId)
    {
//        $userTemplateRecord = $templateRecord->duplicate(
//            [
//                'user_id' => $userId,
//            ],
//        );

//        if ($userTemplateRecord) {
            //user or account base - just switch class
            $defaultTemplate = DefaultTemplate::model()->findByPk($userId);
            if (!$defaultTemplate) {
                $defaultTemplate = new DefaultTemplate();
                $defaultTemplate->user_id = $userId;
            }
            $defaultTemplate->template_id = $templateRecord->id;
            $defaultTemplate->save();

            //update user record
            User::findById($userId)->change(true);
//        }
    }
}