go.modules.invicta.grouptemplates.AssignTemplateDialog = Ext.extend(go.Window, {

    initComponent: function () {

        Ext.applyIf(this, {
            title: t('Assign template to group'),
            modal: true,
            width: dp(400)
        });

        this.formPanel = new Ext.FormPanel({
            cls: 'go-form-panel',
            layout: 'form',
            items: [
                {
                    items: [
                        new Ext.Button({
                            hidden: true,
                            hideMode: "offsets",
                            type: "submit",
                            handler: function () {
                                this.submitPressed();
                            },
                            scope: this
                        }),
                        this.templateField = new go.modules.invicta.grouptemplates.TemplateCombo({
                            hideLabel: true,
                            anchor: '100%',
                        }),
                    ]
                }
            ]
        });

        Ext.apply(this, {
            autoHeight: true,
            closeAction: 'cancelPressed',
            items: [
                this.formPanel
            ],
            buttons: [
                {
                    text: t("Assign"),
                    handler: this.submitPressed,
                    scope: this
                }
            ]
        });

        this.addEvents({
            'cancel': true,
            'ok': true
        });

        go.modules.invicta.grouptemplates.AssignTemplateDialog.superclass.initComponent.call(this);
    },

    focus: function () {
        this.templateField.focus();
    },

    submitPressed: function () {

        if (this.formPanel.getForm().isValid()) {
            //this.fireEvent('ok', this.passwordField.getValue());
            this.close();
        }
    },

    cancelPressed: function () {
        this.fireEvent('cancel');
        this.close();
    }
});