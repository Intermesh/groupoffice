go.modules.invicta.grouptemplates.SystemSettingsPanel = Ext.extend(go.modules.invicta.grouptemplates.GroupEditorGrid, {
    title: t('Group Templates'),
    iconCls: 'ic-mail',
    labelWidth: 125,
    layout: "form",
    autoScroll: true,
});