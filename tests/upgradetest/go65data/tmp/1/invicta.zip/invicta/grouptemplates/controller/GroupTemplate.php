<?php

namespace go\modules\invicta\grouptemplates\controller;

use GO\Base\Model\Template;
use go\core\exception\NotFound;
use go\core\model;
use go\core\jmap\EntityController;
use go\core\orm\Query;

class GroupTemplate extends EntityController
{
    protected function entityClass()
    {
        return model\Group::class;
    }

    /**
     * @param $params
     * @throws \Exception
     */
    public function applyTemplateToGroupUsers($params)
    {
        $templateRow = (new Query())
            ->select('cgdt.templateId')->distinct()
            ->from('core_group_default_template', 'cgdt')
            ->where(['groupId' => $params['entityId']])->single();

        if (!$templateRow) {
            throw new NotFound('Template not found');
        }

        $templateRecord = Template::model()->findByPk($templateRow['templateId']);
        if (!$templateRecord) {
            throw new NotFound('Template not found');
        }

        /** @var model\Group $group */
        $group = $this->getEntity($params['entityId']);
        if (!$group) {
            throw new NotFound('Group not found');
        }

        foreach ($group->users as $userId) {
            \go\modules\invicta\grouptemplates\model\GroupTemplate::applyTemplateToUser($templateRecord, $userId);
        }
    }
}